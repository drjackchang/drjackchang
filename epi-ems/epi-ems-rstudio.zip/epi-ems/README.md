# 流行病學方法論（EMS 與災難數據版）R 專案

1. 解壓縮到沒有中文與空白的路徑（例如 C:\R\epi-ems）。
2. 雙擊 `epi-ems.Rproj` 開啟 RStudio。
3. 第一次使用請在 Console 執行：`install.packages("survival")`
4. 每週打開 `R/weeks/wNN.R`，由上往下逐段執行（Ctrl+Enter），對照課程網站的「參考輸出」。

- `data/`：15 份模擬資料（虛構城市「北濱市」，不代表任何真實個人或機構）
- `R/sim_data.R`：產生資料的程式（固定亂數種子，重跑結果相同）
